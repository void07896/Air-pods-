import { Product } from './types';

export const PRODUCTS: Product[] = [
  {
    id: '1',
    name: 'Neural Link Pro',
    category: 'Wearables',
    price: 299.99,
    description: 'Next-generation brain-computer interface for seamless productivity and focus tracking.',
    image: 'https://picsum.photos/seed/gadget1/800/600',
    specs: {
      'Battery Life': '24 Hours',
      'Connectivity': 'Bluetooth 5.2',
      'Sensors': 'EEG, PPG, Accelerometer'
    },
    features: ['Real-time focus monitoring', 'Haptic feedback', 'Noise cancellation']
  },
  {
    id: '2',
    name: 'Quantum Watch S3',
    category: 'Wearables',
    price: 499.00,
    description: 'The world\'s first consumer-grade atomic clock synchronization in a wrist-worn form factor.',
    image: 'https://picsum.photos/seed/gadget2/800/600',
    specs: {
      'Precision': '±1s per 100 years',
      'Material': 'Grade 5 Titanium',
      'Water Resistance': '100m'
    },
    features: ['Atomic sync', 'Solar charging', 'Sapphire crystal']
  },
  {
    id: '3',
    name: 'HoloDesk Mini',
    category: 'Computing',
    price: 850.00,
    description: 'Portable holographic display for 3D visualization and immersive workspace expansion.',
    image: 'https://picsum.photos/seed/gadget3/800/600',
    specs: {
      'Resolution': '4K Holographic',
      'Brightness': '1200 nits',
      'Input': 'USB-C / HDMI'
    },
    features: ['Gesture control', 'Eye tracking', 'True 3D depth']
  },
  {
    id: '4',
    name: 'Sonic Shield Earbuds',
    category: 'Audio',
    price: 199.50,
    description: 'Active acoustic isolation that creates a literal bubble of silence in any environment.',
    image: 'https://picsum.photos/seed/gadget4/800/600',
    specs: {
      'ANC': 'Up to 50dB',
      'Drivers': '12mm Beryllium',
      'Latency': '40ms'
    },
    features: ['Adaptive transparency', 'Spatial audio', 'Bone conduction mic']
  },
  {
    id: '5',
    name: 'BioTrack Ring',
    category: 'Wearables',
    price: 249.00,
    description: 'Minimalist smart ring that monitors your vital signs with medical-grade accuracy.',
    image: 'https://picsum.photos/seed/gadget5/800/600',
    specs: {
      'Weight': '4g',
      'Material': 'Zirconia Ceramic',
      'Battery': '7 Days'
    },
    features: ['Sleep staging', 'Stress tracking', 'NFC payments']
  },
  {
    id: '6',
    name: 'Flux Power Station',
    category: 'Power',
    price: 129.00,
    description: 'Ultra-compact GaN charger with integrated power bank and digital status display.',
    image: 'https://picsum.photos/seed/gadget6/800/600',
    specs: {
      'Output': '140W Max',
      'Capacity': '20,000mAh',
      'Ports': '3x USB-C, 1x USB-A'
    },
    features: ['OLED status screen', 'Pass-through charging', 'Flight safe']
  }
];

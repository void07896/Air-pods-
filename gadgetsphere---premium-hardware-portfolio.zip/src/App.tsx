/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ShoppingCart, 
  Cpu, 
  Zap, 
  Shield, 
  Search, 
  X, 
  Plus, 
  Minus, 
  ChevronRight, 
  MessageSquare,
  ArrowRight,
  Monitor,
  Smartphone,
  Watch,
  Battery
} from 'lucide-react';
import { GoogleGenAI } from "@google/genai";
import { PRODUCTS } from './constants';
import { Product, CartItem } from './types';

export default function App() {
  const [cart, setCart] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [isAdvisorOpen, setIsAdvisorOpen] = useState(false);
  const [advisorMessage, setAdvisorMessage] = useState("");
  const [advisorResponse, setAdvisorResponse] = useState("");
  const [isThinking, setIsThinking] = useState(false);

  const addToCart = (product: Product) => {
    setCart(prev => {
      const existing = prev.find(item => item.id === product.id);
      if (existing) {
        return prev.map(item => item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item);
      }
      return [...prev, { ...product, quantity: 1 }];
    });
  };

  const removeFromCart = (id: string) => {
    setCart(prev => prev.filter(item => item.id !== id));
  };

  const updateQuantity = (id: string, delta: number) => {
    setCart(prev => prev.map(item => {
      if (item.id === id) {
        const newQty = Math.max(1, item.quantity + delta);
        return { ...item, quantity: newQty };
      }
      return item;
    }));
  };

  const cartTotal = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);

  const askAdvisor = async () => {
    if (!advisorMessage.trim()) return;
    setIsThinking(true);
    setAdvisorResponse("");
    
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: `You are a gadget expert at GadgetSphere. Help the user choose from our catalog: ${JSON.stringify(PRODUCTS)}. User question: ${advisorMessage}`,
        config: {
          systemInstruction: "Be concise, technical yet approachable. Use a professional 'hardware specialist' tone."
        }
      });
      setAdvisorResponse(response.text || "I'm sorry, I couldn't process that.");
    } catch (error) {
      console.error(error);
      setAdvisorResponse("Connection to Neural Link failed. Please try again.");
    } finally {
      setIsThinking(false);
    }
  };

  return (
    <div className="min-h-screen selection:bg-emerald-500/30">
      {/* Navigation */}
      <nav className="fixed top-0 w-full z-50 glass-panel border-b border-white/5 px-6 py-4 flex justify-between items-center">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-emerald-500 rounded-lg flex items-center justify-center">
            <Cpu className="text-black w-5 h-5" />
          </div>
          <span className="font-mono font-bold tracking-tighter text-xl">GADGETSPHERE</span>
        </div>
        
        <div className="hidden md:flex gap-8 text-sm font-medium text-white/60">
          <a href="#" className="hover:text-emerald-400 transition-colors">CATALOG</a>
          <a href="#" className="hover:text-emerald-400 transition-colors">TECHNOLOGY</a>
          <a href="#" className="hover:text-emerald-400 transition-colors">SUPPORT</a>
        </div>

        <div className="flex items-center gap-4">
          <button 
            onClick={() => setIsCartOpen(true)}
            className="relative p-2 hover:bg-white/5 rounded-full transition-colors"
          >
            <ShoppingCart className="w-5 h-5" />
            {cart.length > 0 && (
              <span className="absolute -top-1 -right-1 bg-emerald-500 text-black text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center">
                {cart.length}
              </span>
            )}
          </button>
        </div>
      </nav>

      {/* Hero Section */}
      <header className="relative pt-32 pb-20 px-6 overflow-hidden hardware-grid">
        <div className="max-w-7xl mx-auto grid lg:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
          >
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs font-mono mb-6">
              <Zap className="w-3 h-3" />
              <span>NEW RELEASE: NEURAL LINK PRO</span>
            </div>
            <h1 className="text-6xl md:text-8xl font-serif italic font-bold leading-tight mb-6">
              The Future <br />
              <span className="text-emerald-400 glow-text">Is Modular.</span>
            </h1>
            <p className="text-white/50 text-lg max-w-md mb-8 leading-relaxed">
              Experience hardware that adapts to your workflow. Precision-engineered gadgets for the modern specialist.
            </p>
            <div className="flex gap-4">
              <button className="px-8 py-4 bg-emerald-500 text-black font-bold rounded-full hover:bg-emerald-400 transition-all flex items-center gap-2">
                EXPLORE CATALOG <ArrowRight className="w-4 h-4" />
              </button>
              <button 
                onClick={() => setIsAdvisorOpen(true)}
                className="px-8 py-4 border border-white/10 rounded-full hover:bg-white/5 transition-all font-medium"
              >
                TALK TO AI ADVISOR
              </button>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="relative aspect-square"
          >
            <div className="absolute inset-0 bg-emerald-500/20 blur-[120px] rounded-full" />
            <img 
              src="https://picsum.photos/seed/hero-gadget/1000/1000" 
              alt="Featured Gadget"
              className="relative w-full h-full object-cover rounded-3xl border border-white/10 shadow-2xl"
              referrerPolicy="no-referrer"
            />
            <div className="absolute -bottom-6 -left-6 glass-panel p-6 rounded-2xl border border-white/10 max-w-[240px]">
              <div className="flex items-center gap-3 mb-2">
                <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                <span className="text-[10px] font-mono text-white/40 uppercase tracking-widest">System Status</span>
              </div>
              <p className="text-sm font-medium">Neural Link Pro v2.4 Active</p>
              <div className="mt-4 h-1 w-full bg-white/5 rounded-full overflow-hidden">
                <div className="h-full w-3/4 bg-emerald-500" />
              </div>
            </div>
          </motion.div>
        </div>
      </header>

      {/* Product Grid */}
      <section className="py-24 px-6 max-w-7xl mx-auto">
        <div className="flex justify-between items-end mb-12">
          <div>
            <h2 className="text-xs font-mono text-emerald-400 mb-2 tracking-[0.3em] uppercase">Curated Collection</h2>
            <h3 className="text-4xl font-bold">Specialist Tools</h3>
          </div>
          <div className="flex gap-2">
            {['All', 'Wearables', 'Computing', 'Audio'].map(cat => (
              <button key={cat} className="px-4 py-2 rounded-full text-xs font-medium border border-white/5 hover:border-emerald-500/50 transition-all">
                {cat}
              </button>
            ))}
          </div>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {PRODUCTS.map((product, idx) => (
            <motion.div
              key={product.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.1 }}
              className="group relative bg-card-bg rounded-2xl border border-white/5 overflow-hidden hover:border-emerald-500/30 transition-all"
            >
              <div className="aspect-[4/3] overflow-hidden">
                <img 
                  src={product.image} 
                  alt={product.name}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  referrerPolicy="no-referrer"
                />
              </div>
              <div className="p-6">
                <div className="flex justify-between items-start mb-2">
                  <span className="text-[10px] font-mono text-emerald-400 uppercase tracking-widest">{product.category}</span>
                  <span className="text-sm font-mono">${product.price}</span>
                </div>
                <h4 className="text-xl font-bold mb-2">{product.name}</h4>
                <p className="text-white/40 text-sm mb-6 line-clamp-2">{product.description}</p>
                <div className="flex gap-2">
                  <button 
                    onClick={() => setSelectedProduct(product)}
                    className="flex-1 py-3 border border-white/10 rounded-xl text-xs font-bold hover:bg-white/5 transition-all"
                  >
                    DETAILS
                  </button>
                  <button 
                    onClick={() => addToCart(product)}
                    className="w-12 h-12 bg-emerald-500 text-black rounded-xl flex items-center justify-center hover:bg-emerald-400 transition-all"
                  >
                    <Plus className="w-5 h-5" />
                  </button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Product Modal */}
      <AnimatePresence>
        {selectedProduct && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-6">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSelectedProduct(null)}
              className="absolute inset-0 bg-black/80 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="relative w-full max-w-4xl bg-card-bg rounded-3xl border border-white/10 overflow-hidden grid md:grid-cols-2"
            >
              <div className="h-full bg-black">
                <img 
                  src={selectedProduct.image} 
                  alt={selectedProduct.name}
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              </div>
              <div className="p-8 md:p-12 overflow-y-auto max-h-[80vh]">
                <button 
                  onClick={() => setSelectedProduct(null)}
                  className="absolute top-6 right-6 p-2 hover:bg-white/5 rounded-full"
                >
                  <X className="w-5 h-5" />
                </button>
                
                <span className="text-xs font-mono text-emerald-400 uppercase tracking-widest mb-4 block">
                  {selectedProduct.category}
                </span>
                <h2 className="text-4xl font-bold mb-4">{selectedProduct.name}</h2>
                <p className="text-white/50 mb-8 leading-relaxed">{selectedProduct.description}</p>
                
                <div className="space-y-6 mb-8">
                  <div>
                    <h5 className="text-[10px] font-mono text-white/30 uppercase tracking-widest mb-3">Technical Specs</h5>
                    <div className="grid grid-cols-2 gap-4">
                      {Object.entries(selectedProduct.specs).map(([key, val]) => (
                        <div key={key} className="p-3 rounded-lg bg-white/5 border border-white/5">
                          <p className="text-[10px] text-white/40 mb-1">{key}</p>
                          <p className="text-xs font-medium">{val}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                  
                  <div>
                    <h5 className="text-[10px] font-mono text-white/30 uppercase tracking-widest mb-3">Key Features</h5>
                    <ul className="space-y-2">
                      {selectedProduct.features.map(f => (
                        <li key={f} className="flex items-center gap-2 text-xs text-white/60">
                          <div className="w-1 h-1 rounded-full bg-emerald-500" />
                          {f}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-8 border-t border-white/5">
                  <span className="text-2xl font-mono font-bold">${selectedProduct.price}</span>
                  <button 
                    onClick={() => {
                      addToCart(selectedProduct);
                      setSelectedProduct(null);
                    }}
                    className="px-8 py-4 bg-emerald-500 text-black font-bold rounded-full hover:bg-emerald-400 transition-all"
                  >
                    ADD TO CART
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Cart Drawer */}
      <AnimatePresence>
        {isCartOpen && (
          <div className="fixed inset-0 z-[100] flex justify-end">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsCartOpen(false)}
              className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="relative w-full max-w-md bg-card-bg border-l border-white/10 flex flex-col"
            >
              <div className="p-6 border-b border-white/5 flex justify-between items-center">
                <h3 className="text-xl font-bold flex items-center gap-2">
                  <ShoppingCart className="w-5 h-5" /> YOUR CART
                </h3>
                <button onClick={() => setIsCartOpen(false)} className="p-2 hover:bg-white/5 rounded-full">
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="flex-1 overflow-y-auto p-6 space-y-6">
                {cart.length === 0 ? (
                  <div className="h-full flex flex-col items-center justify-center text-white/30">
                    <ShoppingCart className="w-12 h-12 mb-4 opacity-20" />
                    <p>Your cart is empty</p>
                  </div>
                ) : (
                  cart.map(item => (
                    <div key={item.id} className="flex gap-4">
                      <div className="w-20 h-20 rounded-xl overflow-hidden bg-black flex-shrink-0">
                        <img src={item.image} alt={item.name} className="w-full h-full object-cover" />
                      </div>
                      <div className="flex-1">
                        <div className="flex justify-between mb-1">
                          <h4 className="font-bold text-sm">{item.name}</h4>
                          <button onClick={() => removeFromCart(item.id)} className="text-white/30 hover:text-red-400">
                            <X className="w-4 h-4" />
                          </button>
                        </div>
                        <p className="text-xs text-white/40 mb-3">${item.price}</p>
                        <div className="flex items-center gap-3">
                          <button 
                            onClick={() => updateQuantity(item.id, -1)}
                            className="w-6 h-6 rounded-md border border-white/10 flex items-center justify-center hover:bg-white/5"
                          >
                            <Minus className="w-3 h-3" />
                          </button>
                          <span className="text-xs font-mono">{item.quantity}</span>
                          <button 
                            onClick={() => updateQuantity(item.id, 1)}
                            className="w-6 h-6 rounded-md border border-white/10 flex items-center justify-center hover:bg-white/5"
                          >
                            <Plus className="w-3 h-3" />
                          </button>
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>

              <div className="p-6 border-t border-white/5 bg-black/20">
                <div className="flex justify-between mb-4">
                  <span className="text-white/40">Subtotal</span>
                  <span className="font-mono font-bold">${cartTotal.toFixed(2)}</span>
                </div>
                <button 
                  disabled={cart.length === 0}
                  className="w-full py-4 bg-emerald-500 text-black font-bold rounded-xl hover:bg-emerald-400 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  CHECKOUT
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* AI Advisor Widget */}
      <div className="fixed bottom-6 right-6 z-50">
        <AnimatePresence>
          {isAdvisorOpen && (
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="absolute bottom-20 right-0 w-[350px] glass-panel rounded-2xl overflow-hidden shadow-2xl"
            >
              <div className="p-4 bg-emerald-500 text-black flex justify-between items-center">
                <div className="flex items-center gap-2">
                  <MessageSquare className="w-4 h-4" />
                  <span className="text-xs font-bold uppercase tracking-widest">AI Gadget Advisor</span>
                </div>
                <button onClick={() => setIsAdvisorOpen(false)}>
                  <X className="w-4 h-4" />
                </button>
              </div>
              <div className="p-4 h-[300px] overflow-y-auto text-sm space-y-4">
                {advisorResponse ? (
                  <div className="p-3 rounded-xl bg-white/5 border border-white/5">
                    <p className="text-white/80 leading-relaxed">{advisorResponse}</p>
                  </div>
                ) : (
                  <p className="text-white/40 italic text-center mt-12">
                    Ask me anything about our hardware collection...
                  </p>
                )}
                {isThinking && (
                  <div className="flex gap-1 items-center p-3 rounded-xl bg-white/5 w-fit">
                    <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-bounce" />
                    <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-bounce [animation-delay:0.2s]" />
                    <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-bounce [animation-delay:0.4s]" />
                  </div>
                )}
              </div>
              <div className="p-4 border-t border-white/5">
                <div className="flex gap-2">
                  <input 
                    type="text" 
                    value={advisorMessage}
                    onChange={(e) => setAdvisorMessage(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && askAdvisor()}
                    placeholder="Which gadget is best for..."
                    className="flex-1 bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-xs focus:outline-none focus:border-emerald-500/50"
                  />
                  <button 
                    onClick={askAdvisor}
                    disabled={isThinking}
                    className="p-2 bg-emerald-500 text-black rounded-lg hover:bg-emerald-400 disabled:opacity-50"
                  >
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
        <button 
          onClick={() => setIsAdvisorOpen(!isAdvisorOpen)}
          className="w-14 h-14 bg-emerald-500 text-black rounded-full shadow-lg flex items-center justify-center hover:scale-110 transition-transform"
        >
          <MessageSquare className="w-6 h-6" />
        </button>
      </div>

      {/* Footer */}
      <footer className="py-20 px-6 border-t border-white/5 bg-black/40">
        <div className="max-w-7xl mx-auto grid md:grid-cols-4 gap-12">
          <div className="col-span-2">
            <div className="flex items-center gap-2 mb-6">
              <div className="w-6 h-6 bg-emerald-500 rounded flex items-center justify-center">
                <Cpu className="text-black w-4 h-4" />
              </div>
              <span className="font-mono font-bold tracking-tighter text-lg">GADGETSPHERE</span>
            </div>
            <p className="text-white/40 max-w-sm text-sm leading-relaxed">
              Pushing the boundaries of consumer hardware. We build tools for the next generation of digital specialists.
            </p>
          </div>
          <div>
            <h5 className="text-[10px] font-mono text-white/30 uppercase tracking-widest mb-6">Navigation</h5>
            <ul className="space-y-4 text-sm text-white/60">
              <li><a href="#" className="hover:text-emerald-400 transition-colors">Catalog</a></li>
              <li><a href="#" className="hover:text-emerald-400 transition-colors">Technology</a></li>
              <li><a href="#" className="hover:text-emerald-400 transition-colors">Support</a></li>
              <li><a href="#" className="hover:text-emerald-400 transition-colors">Privacy</a></li>
            </ul>
          </div>
          <div>
            <h5 className="text-[10px] font-mono text-white/30 uppercase tracking-widest mb-6">Connect</h5>
            <ul className="space-y-4 text-sm text-white/60">
              <li><a href="#" className="hover:text-emerald-400 transition-colors">Twitter</a></li>
              <li><a href="#" className="hover:text-emerald-400 transition-colors">Instagram</a></li>
              <li><a href="#" className="hover:text-emerald-400 transition-colors">Discord</a></li>
              <li><a href="#" className="hover:text-emerald-400 transition-colors">GitHub</a></li>
            </ul>
          </div>
        </div>
        <div className="max-w-7xl mx-auto mt-20 pt-8 border-t border-white/5 flex justify-between items-center text-[10px] font-mono text-white/20">
          <span>© 2026 GADGETSPHERE INDUSTRIES</span>
          <div className="flex gap-6">
            <span>ENCRYPTED CONNECTION</span>
            <span>SYSTEM STATUS: OPTIMAL</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
